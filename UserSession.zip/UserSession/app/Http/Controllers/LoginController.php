<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\User;
use Session;
use Auth;
use DB;
use Validator;

class LoginController extends Controller
{ 
    public function index(Request $request){
    	
        $validation = Validator::make($request->all(),[ 
            'user_id' => 'required',
            'pass'  => 'required',
        ]);

        $response_array = [];
        if($validation->fails()){
     
            $response_array['response'] =  $validation->messages();
            $data = json_encode($response_array);
            return $data;
   
        }else{
            $curr_session = Str::random(60);
            $id= $request->user_id;
            $pass = md5($request->pass);
            $data = User::find($id);
           // $data = json_decode(json_encode($data),true);
            $tokenData = array(
                'session_id'  => $curr_session,
            );
            if( $data->password == $pass ) {
                //dd('if');
                $previous_token = $data->session_id;
                if($previous_token != $curr_session && $previous_token != ''){
                    $response_array['Message']  = 'Previous Sessions in Progress';
				    $data = json_encode($response_array);
                    return $data;
                }else{
                    $update = DB::table('users')->where('id',$id)->update($tokenData);
                    $response_array['Message']  = 'Login Successfully';
				
                    $data = json_encode($response_array);
        
                    return $data;
                }
            }
            else{ 
                $response_array['Message']  = 'Invalid User Name or Password';
				
                $data = json_encode($response_array);
    
                return $data;
            }
            
       }
    }

    public function logout(Request $request){
        $id= $request->user_id;
        $data = User::find($id);
        //$data = json_decode(json_encode($data),true);
        $response_array = [];
        $tokenData = array(
            'session_id'  => '',
        );
        if(!empty($data)){
            $previous_token = $data->session_id;
            if($previous_token != ''){
                $update = DB::table('users')->where('id',$id)->update($tokenData);
                $response_array['Message']  = 'Logout Successfully';
            
                $data = json_encode($response_array);
    
                return $data;
            
            }
            else{
                $response_array['Message']  = 'Something Went Wrong';
            
                $data = json_encode($response_array);
    
                return $data;
            }
        }
    }
}
