<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'Rina',
            'email'=> 'rina@gmail.com',
            'password' => md5('rina@123'),
        ]);

        DB::table('users')->insert([
            'name' => 'Rajni',
            'email'=> 'rajni@gmail.com',
            'password' => md5('rajni@123'),
        ]);
    }
}
